** DELETE node_modules folder in the PROJECT folder **

1. download the foler "weatherly"
2. go to terminal and type " npm install "
3. after installation, type " npm run dev" to start
4. go to browser, type "localhost:8080"
5. in the search bar, type the name of the "city"

** note that you might not have access to api keys due to .gitignore 
check discord for the api keys.
